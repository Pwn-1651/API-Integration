import streamlit as st
import requests

st.title("ML Model API Integration")

user_input=st.number_input("enter value")

if st.button("predict"):
    url="http://127.0.0.1:8000/predict"

    data={
        "input":user_input
    }

    response=requests.post(url,json=data)

    result=response.json()
    st.success(f"prediction:{result['prediction'][0]}")