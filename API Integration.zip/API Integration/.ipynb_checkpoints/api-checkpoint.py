from fastapi import FastAPI
import joblib
import numpy as np

app=FastAPI()

model= joblib.load("model.pkl")

@app.get("/")
def home():
    return{"message":"API running"}

@app.post("/predict")
def predict(data: dict):
    value=data["input"]
    prediction=model.predict(np.array([[value]]))
    return{"prediction":prediction.tolist()}
    